CAN GOD BE TRUSTED? — VOLUME 2
Ready-to-upload website files

UPLOAD STRUCTURE:

Your GitHub repository root:
  can-god-be-trusted-v2.png

Inside the /devotionals folder:
  can-god-be-trusted-v2-week-1.html
  can-god-be-trusted-v2-week-2.html
  can-god-be-trusted-v2-week-3.html
  can-god-be-trusted-v2-week-4.html
  can-god-be-trusted-v2-week-5.html

IMPORTANT:
1. Keep the image filename exactly: can-god-be-trusted-v2.png
2. Put the five HTML files inside /devotionals/
3. The pages already include the Memberstack script and logout button.
4. Week-to-week navigation is already connected.
5. After uploading, protect the entire /devotionals/ folder in Memberstack using a "Starts with" restricted URL rule.
6. Update your devotional library card to link to:
   /devotionals/can-god-be-trusted-v2-week-1.html
